﻿
Public Class Form1
    Dim celsiusActive As Boolean
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim FAHRENHEITValue As Double
        Dim CELSUISValue As Double

        FAHRENHEITValue = Val(TextBox1.Text)
        CELSUISValue = Val(TextBox2.Text)

        Dim ResultFAHRENHEIT As Double = ((CELSUISValue * (9 / 5)) + 32)
        Dim ResultCELSUIS As Double = ((FAHRENHEITValue - 32) * (5 / 9))
        If celsiusActive Then
            TextBox1.Text = ResultFAHRENHEIT
        Else
            TextBox2.Text = ResultCELSUIS
        End If
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        celsiusActive = True
    End Sub


    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        celsiusActive = False
    End Sub
End Class
