﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b, c, n, s As Integer
        a = TextBox1.Text
        b = TextBox2.Text
        n = b - a
        s = 0


        If a < b Then
            Do
                s = s + InputBox("Enter number of sales:")
                c += 1
                ListBox1.Items.Add(s)
            Loop Until c >= n
            ListBox1.Items.Add("Total sales(RM):" & s)
            ListBox1.Items.Add("Average sales(RM):" & s / n)
        Else
            MsgBox("Please enter the correct year.")
        End If
    End Sub

End Class
